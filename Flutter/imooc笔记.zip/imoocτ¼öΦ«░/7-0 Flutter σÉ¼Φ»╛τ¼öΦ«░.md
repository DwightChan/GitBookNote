




# 7-2 学习构建flutter 实力项目

1. 实例项目
    1.  flutter 官方提供的实例项目 在github 上有 https://github.com/flutter/flutter/tree/master/examples
        1.  在flutter sdk 中也有，路径：/examples 文件夹中
    2.  其他收集的项目 https://github.com/flutter/samples
    3.  flutter 基础项目 https://github.com/nisrulz/flutter-examples 
    4.  手机了其他app https://github.com/imapawan/FlutterExampleApps



# 7-3/4 图加载详情

# 7-5/6/7/8/9/10 Animation 

- 基础动画 有哪些？
- builder 动画如何实现？
- 重难点 hero 动画

# 7-11 Flutter 调试技巧


